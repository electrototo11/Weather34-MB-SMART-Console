  
 <?php include('livedata.php');?>

 <div class="modulecaptionchartbaro"><?php echo $lang['Air Quality']?> &nbsp;<blue1>Purple Air</blue1></div> 


 <iframe  class="charttempmodule" src="weather34charts/todayairqualitychart.php" frameborder="0" scrolling="no" width="320px" height="250px"></iframe>  

 
  <div class="legenddewpoint">PM 2.5</div>
 
  
 <?php include('livedata.php');?>
 <div class="modulecaptionchart"><?php echo $lang['Barometer']?> <blue1><?php echo $weather["barometer_units"]; ?></blue1></div> 
 <iframe  class="charttempmodule" src="weather34charts/yearbarometermodulechart2019.php" frameborder="0" scrolling="no" width="320px" height="250px"></iframe>  
 <div class="legenddewpoint">Min 2019</div><div class="legendwetbulb">Max 2019</div>
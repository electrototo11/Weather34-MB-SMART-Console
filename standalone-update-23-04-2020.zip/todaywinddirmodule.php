  
 <?php include('livedata.php');?>
 <div class="modulecaptionchart"><?php echo $lang['Direction']; ?> </div> 
 <iframe  class="charttempmodule" src="weather34charts/todaywinddirectionmodulechart2.php" frameborder="0" scrolling="no" width="320px" height="250px"></iframe>  
 <div class="legenddewpoint"><?php echo $lang['Direction']; ?></div>
  
 <?php include('livedata.php');?>
 <div class="modulecaptionchart"><?php echo $lang['Windspeed']?> <blue1><?php echo $weather["wind_units"]; ?></blue1></div> 
 <iframe  class="charttempmodule" src="weather34charts/yearwindspeedmodulechart2019.php" frameborder="0" scrolling="no" width="320px" height="250px"></iframe>  
 <div class="legendtemp">Daily Max 2019</div> 
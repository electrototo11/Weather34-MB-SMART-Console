# Weather34 MB-SMART Console
# A stand alone version of the alternative console layout for OEM screens/Tablets/Devices/Smart TV/Desktop
# Requires Meteobridge NANOSD or Meteobridge Pro/TP-Link(type)
 
 
 <img src="https://res.cloudinary.com/brian-underdown/image/upload/v1582531310/Weather34-smart-console.png" width="800px">
 
 
# This work is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License. http://creativecommons.org/licenses/by-nc-nd/4.0/
*This work means CSS/SVG/PHP .*removing id identifiers from SVG icons created by weather34 is not ethical!! you know who you are just be ethical its the unethical practice that produces those annoying emails .


<img src="https://res.cloudinary.com/brian-underdown/image/upload/v1582019911/2_jgxwjk.png" width="550px">

<img src="https://res.cloudinary.com/brian-underdown/image/upload/v1582531101/weather34-smart-tv_ruan0j.png" width="550px">


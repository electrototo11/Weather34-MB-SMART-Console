  
 <?php include('livedata.php');?>
 <div class="modulecaptionchart"><?php echo $lang['Temperature']?> <blue1>&deg;<?php echo $weather["temp_units"]; ?></blue1></div> 
 <iframe  class="charttempmodule" src="weather34charts/yeartemperaturemodulechart2019.php" frameborder="0" scrolling="no" width="320px" height="250px"></iframe>  
 <div class="legenddewpoint">Min 2019</div><div class="legendwetbulb">Max 2019</div>